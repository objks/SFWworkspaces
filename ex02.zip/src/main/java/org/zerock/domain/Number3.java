package org.zerock.domain;

import lombok.Data;

@Data
public class Number3 {
	private int num1;
	private int num2;
	private int num3;
	
	private String id;
	private String pw;
}
