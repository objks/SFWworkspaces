package org.zerock.domain;


import lombok.Data;

@Data
public class BoardVO {

	private int	seq;
  private String id;
  private String username;
  private String content;
  private String email;
  private String serialnum;
  // private Date updateDate;
}
